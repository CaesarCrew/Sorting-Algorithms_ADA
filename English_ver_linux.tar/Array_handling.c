#include "Array_handling.h"

int * generate_array_random(int size_array, char * filename) {
    FILE *f = fopen(filename, "w");
    if (f == NULL) {
        printf("Error opening file\n");
        return 0;
    }

    srand(time(NULL));
    for (int i = 0; i < size_array; i++) {
        int random_number = rand();
        fprintf(f, "%d ", random_number);
    }
    fclose(f);
}

void load_array_from_file(char * filename, int* array, int size_array) {
    FILE *f = fopen(filename, "r");
    if (f == NULL) {
        printf("Error opening the file %s\n", filename);
        return;
    }

    for (int i = 0; i < size_array; i++) {
        if (fscanf(f, "%d", &array[i]) != 1) {
            printf("Could not read number from file\n");
            break;
        }
    }

    fclose(f);
}

int * generate_array_ascending(int size_array, char * filename) {
    FILE *f = fopen(filename, "w");
    if (f == NULL) {
        printf("Error opening file");
        return 0;
    }

    srand(time(NULL));

    int *array = (int *)malloc(size_array * sizeof(int));
    for (int i = 0; i < size_array; i++) {
        array[i] = rand();
    }

    for (int i = 0; i < size_array - 1; i++) {
        for (int j = 0; j < size_array - i - 1; j++) {
            if (array[j] > array[j + 1]) {
                int temp = array[j];
                array[j] = array[j + 1];
                array[j + 1] = temp;
            }
        }
    }

    for (int i = 0; i < size_array; i++) {
        fprintf(f, "%d ", array[i]);
    }

    fclose(f);
    free(array);
}

int * generate_array_descending(int size_array, char * filename) {
    FILE *f = fopen(filename, "w");
    if (f == NULL) {
        printf("Error opening file\n");
        return 0;
    }

    srand(time(NULL));

    int *array = (int *)malloc(size_array * sizeof(int));
    for (int i = 0; i < size_array; i++) {
        array[i] = rand();
    }

    for (int i = 0; i < size_array - 1; i++) {
        for (int j = 0; j < size_array - i - 1; j++) {
            if (array[j] < array[j + 1]) {
                int temp = array[j];
                array[j] = array[j + 1];
                array[j + 1] = temp;
            }
        }
    }

    for (int i = 0; i < size_array; i++) {
        fprintf(f, "%d ", array[i]);
    }

    fclose(f);
    free(array);
}
