#include <Windows.h>

#ifndef GET_TIME_H
#define GET_TIME_H

double get_cpu_time();

#endif