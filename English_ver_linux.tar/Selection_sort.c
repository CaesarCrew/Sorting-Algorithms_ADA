#include "Sorting_algorithms.h"

void selection_sort(int *array, int size_array, int *comparisons, int *swaps){
    *comparisons = 0;
    *swaps = 0;

    for (int i = 0; i < size_array - 1; i++) {  
        int min = i;

        for (int j = i + 1; j < size_array; j++) {
            (*comparisons)++;
            if (array[j] < array[min]) {
                min = j;
            }
        }

        if (min != i) {
            int array_aux = array[i];
            array[i] = array[min];
            array[min] = array_aux;
            (*swaps)++;
        }
    }
}