#include "Sorting_algorithms.h"

void bubble_sort(int* array, int size_array, int * comparisons, int * swaps){
    int x = 0;
    *comparisons = 0;
    *swaps = 0;
    
    do {
        for (int i = (size_array - 1); i > x; i--) {
            (*comparisons)++;
            if (array[i - 1] > array[i]) {
                int array_aux = array[i];
                array[i] = array[i - 1];
                array[i - 1] = array_aux;
                (*swaps)++;
            }
        }
        x++;
    } while (x < size_array);
}