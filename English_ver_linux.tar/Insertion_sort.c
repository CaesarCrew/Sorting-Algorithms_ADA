#include "Sorting_algorithms.h"

void insertion_sort(int *array, int size_array, int *comparisons, int *swaps){
    *comparisons = 0;
    *swaps = 0;

    for (int j = 1; j < size_array; j++) {
        for (int i = j; i > 0; i--) {
            (*comparisons)++;
            if (array[i] < array[i - 1]) {
                int array_aux = array[i];
                array[i] = array[i - 1];
                array[i - 1] = array_aux;
                (*swaps)++;
            } else {
                break;
            }
        }
    }
}