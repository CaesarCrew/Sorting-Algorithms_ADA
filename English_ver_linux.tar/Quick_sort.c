#include "Sorting_algorithms.h"

void quick_sort(int *array, int first_pos, int last_pos, int *comparisons, int *swaps){
    if (first_pos < last_pos) { 
        int pivot = array[first_pos];
        int small_pos = first_pos;

        for (int i = first_pos + 1; i <= last_pos; i++) {
            (*comparisons)++;
            if (array[i] < pivot) {
                small_pos++;
                
                int array_aux = array[i];
                array[i] = array[small_pos];
                array[small_pos] = array_aux;
                
                (*swaps)++;
            }
        }

        array[first_pos] = array[small_pos];
        array[small_pos] = pivot;
        (*swaps)++;

        quick_sort(array, first_pos, small_pos - 1, comparisons, swaps);
        quick_sort(array, small_pos + 1, last_pos, comparisons, swaps);
    }
}