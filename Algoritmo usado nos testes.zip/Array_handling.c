#include "Array_handling.h"

int * generate_array_random(int size_array, char * filename) {
    FILE *f = fopen(filename, "w");
    if (f == NULL) {
        printf("Erro abrindo o arquivo\n");
        return 0;
    }

    srand(time(NULL));
    for (int i = 0; i < size_array; i++) {
        int random_number = rand();
        fprintf(f, "%d ", random_number);
    }
    fclose(f);
}

void load_array_from_file(char * filename, int* array, int size_array) {
    setlocale(LC_ALL, "Portuguese_Brazil.UTF-8");
    FILE *f = fopen(filename, "r");
    if (f == NULL) {
        printf("Erro abrindo o arquivo %s\n", filename);
        return;
    }

    for (int i = 0; i < size_array; i++) {
        if (fscanf(f, "%d", &array[i]) != 1) {
            printf("Erro ao ler um número do arquivo\n");
            break;
        }
    }

    fclose(f);
}

int * generate_array_ascending(int size_array, char * filename) {
    FILE *f = fopen(filename, "w");
    if (f == NULL) {
        printf("Erro abrindo o arquivo");
        return 0;
    }

    srand(time(NULL));

    int *array = (int *)malloc(size_array * sizeof(int));
    for (int i = 0; i < size_array; i++) {
        array[i] = rand();
    }

    for (int i = 0; i < size_array - 1; i++) {
        for (int j = 0; j < size_array - i - 1; j++) {
            if (array[j] > array[j + 1]) {
                int temp = array[j];
                array[j] = array[j + 1];
                array[j + 1] = temp;
            }
        }
    }

    for (int i = 0; i < size_array; i++) {
        fprintf(f, "%d ", array[i]);
    }

    fclose(f);
    free(array);
}

int * generate_array_descending(int size_array, char * filename) {
    FILE *f = fopen(filename, "w");
    if (f == NULL) {
        printf("Erro abrindo o arquivo\n");
        return 0;
    }

    srand(time(NULL));

    int *array = (int *)malloc(size_array * sizeof(int));
    for (int i = 0; i < size_array; i++) {
        array[i] = rand();
    }

    for (int i = 0; i < size_array - 1; i++) {
        for (int j = 0; j < size_array - i - 1; j++) {
            if (array[j] < array[j + 1]) {
                int temp = array[j];
                array[j] = array[j + 1];
                array[j + 1] = temp;
            }
        }
    }

    for (int i = 0; i < size_array; i++) {
        fprintf(f, "%d ", array[i]);
    }

    fclose(f);
    free(array);
}
