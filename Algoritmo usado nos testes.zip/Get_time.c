#include "Get_time.h"

double get_cpu_time() {
    LARGE_INTEGER freq, start;
    QueryPerformanceFrequency(&freq);
    QueryPerformanceCounter(&start);

    return (double)start.QuadPart / freq.QuadPart;
}