#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <locale.h>

#ifndef HANDLING_H
#define HANDLING_H

int * generate_array_random(int, char *);
int * generate_array_ascending(int, char *);
int * generate_array_descending(int, char *);
void load_array_from_file(char *, int *, int);

#endif