#include "Array_handling.h"
#include "Sorting_algorithms.h"
#include "Get_time.h"
#include <string.h>

int main() {
    int size_array, comparisons, swaps, option, option2;
    char filename[24];

    setlocale(LC_ALL, "Portuguese_Brazil.UTF-8");

    printf("Escolha a quantidade de elementos com os quais deseja testar:\n");
    printf("1 = 1000 elementos\n");
    printf("2 = 10000 elementos\n");
    printf("3 = 50000 elementos\n");
    printf("4 = 100000 elementos\n");
    scanf("%d", &option);
    switch (option)
    {
    case 1:
        size_array = 1000;
        break;
    case 2:
        size_array = 10000;
        break;
    case 3:
        size_array = 50000;
        break;
    case 4:
        size_array = 100000;
        break;
    default:
        printf("Não é uma opção");
        break;
    }

    int *array = (int *)malloc(size_array * sizeof(int));
        if (array == NULL) {
            printf("Erro alocando memória para o array.\n");
            return 1;
        }

    printf("Escolha o modelo do array a ser testado:\n");
    printf("1 = Elementos em ordem aleatória\n");
    printf("2 = Elementos já ordenados\n");
    printf("3 = Elementos reversamente ordenados\n");
    scanf("%d", &option2);
    switch (option2)
    {
    case 1:
        sprintf(filename, "Test arrays/Teste%d_1.txt", size_array);
        load_array_from_file(filename, array, size_array);
        break;
    case 2:
        sprintf(filename, "Test arrays/Teste%d_index.txt", size_array);
        load_array_from_file(filename, array, size_array);
        break;
    case 3:
        sprintf(filename, "Test arrays/Teste%d_reverse.txt", size_array);
        load_array_from_file(filename, array, size_array);
        break;
    default:
        break;
    }

    double start, end;
    printf("Escolha qual algoritmo deseja testar:\n");
    printf("1 = Bubble sort\n");
    printf("2 = Selection sort\n");
    printf("3 = Insertion sort\n");
    printf("4 = Merge sort\n");
    printf("5 = Quick sort\n");
    printf("6 = Heap sort\n");
    scanf("%d", &option);
    switch (option)
    {
    case 1:
        start  = get_cpu_time();
        bubble_sort(array, size_array, &comparisons, &swaps);
        end  = get_cpu_time();
        break;
    case 2:
        start  = get_cpu_time();
        selection_sort(array, size_array, &comparisons, &swaps);
        end  = get_cpu_time();
        break;
    case 3:
        start  = get_cpu_time();
        insertion_sort(array, size_array, &comparisons, &swaps);
        end  = get_cpu_time();
        fflush(stdout);
        break;
    case 4:
        start  = get_cpu_time();
        merge_sort(array, 0, size_array, &comparisons, &swaps);
        end  = get_cpu_time();
        fflush(stdout);
        break;
    case 5:
        start  = get_cpu_time();
        quick_sort(array, 0, size_array, &comparisons, &swaps);
        end  = get_cpu_time();
        fflush(stdout);
        break;
    case 6:
        start  = get_cpu_time();
        heap_sort(array, size_array, &comparisons, &swaps);
        end  = get_cpu_time();
        fflush(stdout);
        break;
    default:
        break;
    }

    fflush(stdout);
    
    switch (option2)
    {
    case 1:
        printf("\nUsando a ordem aleatória:\n");
        break;
    case 2:
        printf("\nUsando vetor ordenado:\n");
        break;
    case 3:
        printf("\nUsando vetor reversamente ordenado:\n");
        break;
    default:
        break;
    }
    printf("Tempo na CPU  = %9f\n", end  - start);
    printf("Número de comparações: %d\n", comparisons);
    printf("Número de trocas: %d\n", swaps);
    fflush(stdout);

    free(array);
    return 0;
}