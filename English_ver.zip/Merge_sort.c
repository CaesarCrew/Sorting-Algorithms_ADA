#include "Sorting_algorithms.h"

void merge_sort(int *array, int first_pos, int last_pos, int *comparisons, int *swaps){
    if (first_pos < last_pos) {
        int middle = first_pos + ((last_pos - first_pos) / 2);

        merge_sort(array, first_pos, middle, comparisons, swaps);
        merge_sort(array, middle + 1, last_pos, comparisons, swaps);
        
        int size_left = (middle - first_pos) + 1;
        int size_right = last_pos - middle;

        int *L = (int *)malloc(size_left * sizeof(int));
        int *R = (int *)malloc(size_right * sizeof(int));

        for (int i = 0; i < size_left; i++) {
            L[i] = array[first_pos + i];
        }
        for (int j = 0; j < size_right; j++) {
            R[j] = array[middle + 1 + j];
        }

        int i = 0, j = 0, k = first_pos;
        while (i < size_left && j < size_right) {
            (*comparisons)++;
            if (L[i] <= R[j]) {
                array[k] = L[i];
                i++;
            } else {
                array[k] = R[j];
                j++;
            }
            k++;
            (*swaps)++;
        }

        while (i < size_left) {
            array[k] = L[i];
            i++;
            k++;
            (*swaps)++;
        }

        while (j < size_right) {
            array[k] = R[j];
            j++;
            k++;
            (*swaps)++;
        }

        free(L);
        free(R);
        }
}