#include "Array_handling.h"
#include "Sorting_algorithms.h"
#include "Get_time.h"
#include <string.h>

int main() {
    int size_array, comparisons, swaps, option;
    char filename[24];

    printf("Choose the size of the array you want to test:\n");
    printf("1 = 1000 elements\n");
    printf("2 = 10000 elements\n");
    printf("3 = 50000 elements\n");
    printf("4 = 100000 elements\n");
    scanf("%d", &option);
    switch (option)
    {
    case 1:
        size_array = 1000;
        break;
    case 2:
        size_array = 10000;
        break;
    case 3:
        size_array = 50000;
        break;
    case 4:
        size_array = 100000;
        break;
    default:
        printf("Not available");
        break;
    }

    int *array = (int *)malloc(size_array * sizeof(int));
        if (array == NULL) {
            printf("Error alocating memory for array.\n");
            return 1;
        }

    printf("Choose the case you wish to test:\n");
    printf("1 = Random order\n");
    printf("2 = Sorted array\n");
    printf("3 = Reversely sorted\n");
    scanf("%d", &option);
    switch (option)
    {
    case 1:
        sprintf(filename, "Test arrays/Teste%d_1.txt", size_array);
        load_array_from_file(filename, array, size_array);
        break;
    case 2:
        sprintf(filename, "Test arrays/Teste%d_index.txt", size_array);
        load_array_from_file(filename, array, size_array);
        break;
    case 3:
        sprintf(filename, "Test arrays/Teste%d_reverse.txt", size_array);
        load_array_from_file(filename, array, size_array);
        break;
    default:
        break;
    }

    double start, end;
    printf("Choose wich algorithm you want to test:\n");
    printf("1 = Bubble sort\n");
    printf("2 = Selection sort\n");
    printf("3 = Insertion sort\n");
    printf("4 = Merge sort\n");
    printf("5 = Quick sort\n");
    printf("6 = Heap sort\n");
    scanf("%d", &option);
    switch (option)
    {
    case 1:
        start  = get_cpu_time();
        bubble_sort(array, size_array, &comparisons, &swaps);
        end  = get_cpu_time();
        break;
    case 2:
        start  = get_cpu_time();
        selection_sort(array, size_array, &comparisons, &swaps);
        end  = get_cpu_time();
        break;
    case 3:
        start  = get_cpu_time();
        insertion_sort(array, size_array, &comparisons, &swaps);
        end  = get_cpu_time();
        fflush(stdout);
        break;
    case 4:
        start  = get_cpu_time();
        merge_sort(array, 0, size_array, &comparisons, &swaps);
        end  = get_cpu_time();
        fflush(stdout);
        break;
    case 5:
        start  = get_cpu_time();
        quick_sort(array, 0, size_array, &comparisons, &swaps);
        end  = get_cpu_time();
        fflush(stdout);
        break;
    case 6:
        start  = get_cpu_time();
        heap_sort(array, size_array, &comparisons, &swaps);
        end  = get_cpu_time();
        fflush(stdout);
        break;
    default:
        break;
    }

    fflush(stdout);
    

    printf("\nRandom:\n");
    printf("CPU Time  = %9f\n", end  - start);
    printf("Comparisons: %d\n", comparisons);
    printf("Swaps: %d\n", swaps);
    fflush(stdout);

    free(array);
    return 0;
}