#include "Sorting_algorithms.h"

void heapify(int * array, int size_array, int root, int *comparisons, int * swaps){
    int largest = root;
    int left_son = 2 * root + 1;
    int right_son = 2 * root + 2;

    (*comparisons)++;
    if(left_son<size_array && array[left_son]>array[largest]){
        largest = left_son;
    }

    (*comparisons)++;
    if(right_son<size_array && array[right_son]>array[largest]){
        largest = right_son;
    }

    (*comparisons)++;
    if(largest!= root){
        int array_aux = array[root];
        array[root] = array[largest];
        array[largest] = array_aux;
        (*swaps);

        heapify(array, size_array, largest, comparisons, swaps);
    }
}

void heap_sort(int *array, int size_array, int *comparisons, int *swaps){
    for (int i = size_array / 2 - 1; i >= 0; i--) {
        heapify(array, size_array, i, comparisons, swaps);
    }

    for (int i = size_array - 1; i > 0; i--) {
        int temp = array[0];
        array[0] = array[i];
        array[i] = temp;
        (*swaps)++;

        heapify(array, i, 0, comparisons, swaps);
    }
}