#include <stdlib.h>

#ifndef SORTING_H
#define SORTING_H

void bubble_sort(int*, int, int *, int *);
void selection_sort(int *, int, int *, int *);
void insertion_sort(int *, int, int *, int *);
void merge_sort(int *, int, int, int *, int *);
void quick_sort(int *, int, int, int *, int *);
void heapify(int *, int, int, int *, int *);
void heap_sort(int *, int, int *, int *);

#endif